#!/usr/bin/env bash
# https://privacy.sexy — v0.12.4 — Fri, 13 Oct 2023 23:52:15 GMT
if [ "$EUID" -ne 0 ]; then
  script_path=$([[ "$0" = /* ]] && echo "$0" || echo "$PWD/${0#./}")
  sudo "$script_path" || (
    echo 'Administrator privileges are required.'
    exit 1
  )
  exit 0
fi
export HOME="/home/${SUDO_USER:-${USER}}" # Keep `~` and `$HOME` for user not `/root`.


# ----------------------------------------------------------
# ----------------Stop the Zeitgeist deamon-----------------
# ----------------------------------------------------------
echo '--- Stop the Zeitgeist deamon'
if ! command -v 'zeitgeist-daemon' &> /dev/null; then
  echo 'Skipping because "zeitgeist-daemon" is not found.'
else
  zeitgeist-daemon --quit
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Prevent Zeitgeist from running on startup---------
# ----------------------------------------------------------
echo '--- Prevent Zeitgeist from running on startup'
file='/etc/xdg/autostart/zeitgeist-datahub.desktop'
backup_file="${file}.old"
if [ -f "$file" ]; then
  echo "File exists: $file."
  sudo mv "$file" "$backup_file"
  echo "Moved to: $backup_file."
else
  echo "Skipping, no changes needed."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -----------Disable access to Zeitgeist database-----------
# ----------------------------------------------------------
echo '--- Disable access to Zeitgeist database'
file="$HOME/.local/share/zeitgeist/activity.sqlite"
if [ -f "$file" ]; then
  chmod -rw "$file"
  echo "Successfully disabled read/write access to $file."
else 
  echo "Skipping, no action needed, file does not exist at $file."
fi
# ----------------------------------------------------------


# Uninstall the Zeitgeist package (can break integrated software)
echo '--- Uninstall the Zeitgeist package (can break integrated software)'
if ! command -v 'apt-get' &> /dev/null; then
  echo 'Skipping because "apt-get" is not found.'
else
  apt_package_name='zeitgeist-core'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "\"$apt_package_name\" is installed and will be uninstalled."
  sudo apt-get purge -y "$apt_package_name"
else
  echo "Skipping, no action needed, \"$apt_package_name\" is not installed."
fi
fi
if ! command -v 'pacman' &> /dev/null; then
  echo 'Skipping because "pacman" is not found.'
else
  pkg_package_name='zeitgeist'
if pacman -Qs "$pkg_package_name" > /dev/null ; then
  echo "\"$pkg_package_name\" is installed and will be uninstalled."
  sudo pacman -Rcns "$pkg_package_name" --noconfirm
else
  echo "The package $pkg_package_name is not installed"
fi
fi
if ! command -v 'dnf' &> /dev/null; then
  echo 'Skipping because "dnf" is not found.'
else
  rpm_package_name='zeitgeist'
sudo dnf autoremove -y --skip-broken "$rpm_package_name"
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Opt-out of the popularity contest (revert)--------
# ----------------------------------------------------------
echo '--- Opt-out of the popularity contest (revert)'
config_file='/etc/popularity-contest.conf'
if [ -f "$config_file" ]; then
  sudo sed -i 's/PARTICIPATE=no/PARTICIPATE=yes/g' "$config_file"
else
  echo "Skipping because configuration file ($config_file) is not found. Is popcon installed?"
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------Uninstall Popularity Contest (popcon) (revert)------
# ----------------------------------------------------------
echo '--- Uninstall Popularity Contest (popcon) (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='popularity-contest'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# Remove daily cron entry for Popularity Contest (popcon) (revert)
echo '--- Remove daily cron entry for Popularity Contest (popcon) (revert)'
cronjob_path="/etc/cron.daily/$job_name"
if [[ -f "$cronjob_path" ]]; then
  if [[ -x "$cronjob_path" ]]; then
    echo "Skipping, cronjob \"$job_name\" is already enabled."
  else
    sudo chmod +x "$cronjob_path"
    echo "Succesfully enabled cronjob \"$job_name\"."
  fi
else
  >&2 echo "Failed to enable cronjob \"$job_name\" because it's missing."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Uninstall `reportbug` package (revert)----------
# ----------------------------------------------------------
echo '--- Uninstall `reportbug` package (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='reportbug'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -----Uninstall Python modules for reportbug (revert)------
# ----------------------------------------------------------
echo '--- Uninstall Python modules for reportbug (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='python3-reportbug'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# Uninstall UI for reportbug (`reportbug-gtk` package) (revert)
echo '--- Uninstall UI for reportbug (`reportbug-gtk` package) (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='reportbug-gtk'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Uninstall `pkgstats` package (revert)-----------
# ----------------------------------------------------------
echo '--- Uninstall `pkgstats` package (revert)'
if ! command -v 'pacman' &> /dev/null; then
    >&2 echo 'Cannot revert because "pacman" is not found.'
  else
    pkg_package_name='pkgstats'
if pacman -Qs "$pkg_package_name" > /dev/null ; then
  echo "Skipping, no action needed because \"$pkg_package_name\" is already installed."
else
  echo "\"$pkg_package_name\" is not installed and will be reinstalled."
  sudo pacman -S "$pkg_package_name" --noconfirm
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------Disable weekly pkgstats submission (revert)--------
# ----------------------------------------------------------
echo '--- Disable weekly pkgstats submission (revert)'
if ! command -v 'systemctl' &> /dev/null; then
    >&2 echo 'Cannot revert because "systemctl" is not found.'
  else
    service='pkgstats.timer'
if systemctl list-units --full -all | grep --fixed-strings --quiet "$service"; then # service exists
  if systemctl is-enabled --quiet "$service"; then
    echo "Skipping, $service is already enabled."
  else
    if sudo systemctl enable "$service"; then
      echo "Successfuly enabled $service, it may require reboot to start."
    else
      >&2 echo "Failed to enable $service."
    fi
  fi
else
  >&2 echo "Failed, $service does not exist."
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Disable Zorin OS census pings (revert)----------
# ----------------------------------------------------------
echo '--- Disable Zorin OS census pings (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='zorin-os-census'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------Remove the Zorin OS census unique ID (revert)-------
# ----------------------------------------------------------
echo '--- Remove the Zorin OS census unique ID (revert)'
if [ -f /var/lib/zorin-os-census/uuid ]; then
  echo 'Skipping, uuid already exists.'
else
  sudo mkdir -p /var/lib/zorin-os-census
  uuidgen | sudo tee /var/lib/zorin-os-census/uuid > /dev/null
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# Disable online search results (collects queries) (revert)-
# ----------------------------------------------------------
echo '--- Disable online search results (collects queries) (revert)'
if ! command -v 'gsettings' &> /dev/null; then
    >&2 echo 'Cannot revert because "gsettings" is not found.'
  else
    gsettings set com.canonical.Unity.Lenses remote-content-search all
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------Opt-out of Ubuntu reporting metrics (revert)-------
# ----------------------------------------------------------
echo '--- Opt-out of Ubuntu reporting metrics (revert)'
if ! command -v 'ubuntu-report' &> /dev/null; then
    >&2 echo 'Cannot revert because "ubuntu-report" is not found.'
  else
    if ubuntu-report -f send yes; then
  echo 'Successfully opted in.'
else
  >&2 echo 'Failed to opt in.'
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -Uninstall Ubuntu Report tool (`ubuntu-report`) (revert)--
# ----------------------------------------------------------
echo '--- Uninstall Ubuntu Report tool (`ubuntu-report`) (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='ubuntu-report'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -----------Uninstall `apport` package (revert)------------
# ----------------------------------------------------------
echo '--- Uninstall `apport` package (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='apport'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------------Disable Apport service (revert)--------------
# ----------------------------------------------------------
echo '--- Disable Apport service (revert)'
if ! command -v 'systemctl' &> /dev/null; then
    >&2 echo 'Cannot revert because "systemctl" is not found.'
  else
    service='apport'
if systemctl list-units --full -all | grep --fixed-strings --quiet "$service"; then # service exists
  if systemctl is-enabled --quiet "$service"; then
    echo "Skipping, $service is already enabled."
  else
    if sudo systemctl enable "$service"; then
      echo "Successfuly enabled $service, it may require reboot to start."
    else
      >&2 echo "Failed to enable $service."
    fi
  fi
else
  >&2 echo "Failed, $service does not exist."
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----Opt-out of Apport error messaging system (revert)-----
# ----------------------------------------------------------
echo '--- Opt-out of Apport error messaging system (revert)'
if [ -f /etc/default/apport ]; then
  sudo sed -i 's/enabled=0/enabled=1/g' /etc/default/apport
  echo 'Successfully enabled apport.'
else
  echo 'Skipping, apport is not configured to be disabled.'
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Uninstall `whoopsie` package (revert)-----------
# ----------------------------------------------------------
echo '--- Uninstall `whoopsie` package (revert)'
if ! command -v 'apt-get' &> /dev/null; then
    >&2 echo 'Cannot revert because "apt-get" is not found.'
  else
    apt_package_name='whoopsie'
if status="$(dpkg-query -W --showformat='${db:Status-Status}' "$apt_package_name" 2>&1)" \
    && [ "$status" = installed ]; then
  echo "Skipping, no action needed because \"$apt_package_name\" is already installed."
else
  echo "\"$apt_package_name\" is not installed and will be reinstalled."
  sudo apt-get install -y "$apt_package_name"
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------------Disable Whoopsie service (revert)-------------
# ----------------------------------------------------------
echo '--- Disable Whoopsie service (revert)'
if ! command -v 'systemctl' &> /dev/null; then
    >&2 echo 'Cannot revert because "systemctl" is not found.'
  else
    service='whoopsie'
if systemctl list-units --full -all | grep --fixed-strings --quiet "$service"; then # service exists
  if systemctl is-enabled --quiet "$service"; then
    echo "Skipping, $service is already enabled."
  else
    if sudo systemctl enable "$service"; then
      echo "Successfuly enabled $service, it may require reboot to start."
    else
      >&2 echo "Failed to enable $service."
    fi
  fi
else
  >&2 echo "Failed, $service does not exist."
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Opt-out of reporting crashes (revert)-----------
# ----------------------------------------------------------
echo '--- Opt-out of reporting crashes (revert)'
if [ -f /etc/default/whoopsie ] ; then
  sudo sed -i 's/report_crashes=false/report_crashes=true/' /etc/default/whoopsie
fi
# ----------------------------------------------------------


# Disable connectivity checks (breaks Captive Portal detection) (revert)
echo '--- Disable connectivity checks (breaks Captive Portal detection) (revert)'
if ! command -v '/usr/sbin/NetworkManager' &> /dev/null; then
    >&2 echo 'Cannot revert because "/usr/sbin/NetworkManager" is not found.'
  else
    if [ ! -f "$file" ]; then
  echo 'Skipping, connectivity checks are not disabled.'
else
  sudo rm -fv "$file"
  echo 'Successfuly restored connectivity checks.'
fi
if command -v 'nmcli' &> /dev/null; then
  sudo nmcli general reload
  echo 'Successfuly reloaded configuration.'
else
  echo 'It will take effect after reboot.'
fi
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------Disable Visual Studio Code telemetry (revert)-------
# ----------------------------------------------------------
echo '--- Disable Visual Studio Code telemetry (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'telemetry.telemetryLevel'
target = json.loads('"off"')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'telemetry.enableTelemetry'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'telemetry.enableCrashReporter'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Do not run Microsoft online experiments on Visual Studio Code (revert)
echo '--- Do not run Microsoft online experiments on Visual Studio Code (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.enableExperiments'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Choose manual Visual Studio Code updates over automatic updates (revert)
echo '--- Choose manual Visual Studio Code updates over automatic updates (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'update.mode'
target = json.loads('"none"')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'update.channel'
target = json.loads('"none"')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Prevent fetching Visual Studio Code release notes from Microsoft servers (revert)
echo '--- Prevent fetching Visual Studio Code release notes from Microsoft servers (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'update.showReleaseNotes'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable automatic fetching remote repository in Visual Studio Code (revert)
echo '--- Disable automatic fetching remote repository in Visual Studio Code (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'git.autofetch'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Prevent fetching package information from NPM and Bower in Visual Studio Code (revert)
echo '--- Prevent fetching package information from NPM and Bower in Visual Studio Code (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'npm.fetchOnlinePackageInfo'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable sending search queries to Microsoft in Visual Studio Code (revert)
echo '--- Disable sending search queries to Microsoft in Visual Studio Code (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.settings.enableNaturalLanguageSearch'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable Visual Studio Code automatic type acquisition in TypeScript (revert)
echo '--- Disable Visual Studio Code automatic type acquisition in TypeScript (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'typescript.disableAutomaticTypeAcquisition'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----Disable Visual Studio Code Edit Sessions (revert)-----
# ----------------------------------------------------------
echo '--- Disable Visual Studio Code Edit Sessions (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.experimental.editSessions.enabled'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.experimental.editSessions.autoStore'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.editSessions.autoResume'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'workbench.editSessions.continueOn'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Prevent auto-updates of Visual Studio Code extensions (revert)
echo '--- Prevent auto-updates of Visual Studio Code extensions (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'extensions.autoUpdate'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Prevent automatically checking Visual Studio Code extension updates from Microsoft servers (revert)
echo '--- Prevent automatically checking Visual Studio Code extension updates from Microsoft servers (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'extensions.autoCheckUpdates'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable auto-fetching Microsoft recommendations in Visual Studio Code (revert)
echo '--- Disable auto-fetching Microsoft recommendations in Visual Studio Code (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'extensions.showRecommendationsOnlyOnDemand'
target = json.loads('true')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable synchronizing Visaul Studio Code keybindings (revert)
echo '--- Disable synchronizing Visaul Studio Code keybindings (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'settingsSync.keybindingsPerPlatform'
target = json.loads('false')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable synchronizing Visual Studio Code extension (revert)
echo '--- Disable synchronizing Visual Studio Code extension (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'settingsSync.ignoredExtensions'
target = json.loads('["*"]')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable synchronizing Visual Studio Code settings (revert)
echo '--- Disable synchronizing Visual Studio Code settings (revert)'
if ! command -v 'python3' &> /dev/null; then
    >&2 echo 'Cannot revert because "python3" is not found.'
  else
    python3 <<EOF
from pathlib import Path
import os, json
property_name = 'settingsSync.ignoredSettings'
target = json.loads('["*"]')
home_dir = f'/home/{os.getenv("SUDO_USER", os.getenv("USER"))}'
settings_files = [
  # Global installation (also snap that installs with "--classic" flag)
  f'{home_dir}/.config/Code/User/settings.json',
  # Flatpak installation
  f'{home_dir}/.var/app/com.visualstudio.code/config/Code/User/settings.json'
]
for settings_file in settings_files:
  file=Path(settings_file)
  if not file.is_file():
    print(f'Skipping, file does not exist at "{settings_file}".')
    continue
  print(f'Reading file at "{settings_file}".')
  file_content = file.read_text()
  json_object = json.loads(file_content)
  if property_name not in json_object:
    print(f'Skipping, "{property_name}" is not configured.')
    continue
  existing_value = json_object[property_name]
  if existing_value != target:
    print(f'Skipping, "{property_name}" is configured using {json.dumps(existing_value)} instead of {json.dumps(target)}.')
    continue
  del json_object[property_name]
  new_content = json.dumps(json_object, indent=2)
  file.write_text(new_content)
  print(f'Successfully reverted "{property_name}" setting.')
EOF
  fi
# ----------------------------------------------------------


# Disable connection tests (breaks automatic Wi-Fi login) (revert)
echo '--- Disable connection tests (breaks automatic Wi-Fi login) (revert)'
pref_name='network.captive-portal-service.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------Enable Firefox First party isolation (revert)-------
# ----------------------------------------------------------
echo '--- Enable Firefox First party isolation (revert)'
pref_name='privacy.firstparty.isolate'
pref_value='true'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------Enable Firefox tracking protection (revert)--------
# ----------------------------------------------------------
echo '--- Enable Firefox tracking protection (revert)'
pref_name='privacy.trackingprotection.enabled'
pref_value='true'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Enable Firefox anti-fingerprinting (may break some websites) (revert)
echo '--- Enable Firefox anti-fingerprinting (may break some websites) (revert)'
pref_name='privacy.resistFingerprinting'
pref_value='true'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Disable WebRTC exposure of your private IP address in Firefox (revert)
echo '--- Disable WebRTC exposure of your private IP address in Firefox (revert)'
pref_name='media.peerconnection.ice.default_address_only'
pref_value='true'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Disable Firefox technical and interaction data collection (revert)
echo '--- Disable Firefox technical and interaction data collection (revert)'
pref_name='datareporting.healthreport.uploadEnabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --Disable verbose Firefox telemetry collection (revert)---
# ----------------------------------------------------------
echo '--- Disable verbose Firefox telemetry collection (revert)'
pref_name='toolkit.telemetry.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Disable Firefox telemetry archive (revert)--------
# ----------------------------------------------------------
echo '--- Disable Firefox telemetry archive (revert)'
pref_name='toolkit.telemetry.archive.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Disable Firefox unified telemetry (revert)--------
# ----------------------------------------------------------
echo '--- Disable Firefox unified telemetry (revert)'
pref_name='toolkit.telemetry.unified'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ---------Clear Firefox telemetry user ID (revert)---------
# ----------------------------------------------------------
echo '--- Clear Firefox telemetry user ID (revert)'
pref_name='toolkit.telemetry.cachedClientID'
pref_value='""'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --Minimize Firefox telemetry logging verbosity (revert)---
# ----------------------------------------------------------
echo '--- Minimize Firefox telemetry logging verbosity (revert)'
pref_name='toolkit.telemetry.log.level'
pref_value='Fatal'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Disable dumping Firefox Telemetry log messages to stdout (revert)
echo '--- Disable dumping Firefox Telemetry log messages to stdout (revert)'
pref_name='toolkit.telemetry.log.dump'
pref_value='Fatal'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ---Disable pinging to Firefox telemetry server (revert)---
# ----------------------------------------------------------
echo '--- Disable pinging to Firefox telemetry server (revert)'
pref_name='toolkit.telemetry.server'
pref_value='""'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----------Disable Firefox shutdown ping (revert)----------
# ----------------------------------------------------------
echo '--- Disable Firefox shutdown ping (revert)'
pref_name='toolkit.telemetry.shutdownPingSender.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
pref_name='toolkit.telemetry.shutdownPingSender.enabledFirstSession'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
pref_name='toolkit.telemetry.firstShutdownPing.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Disable Firefox new profile ping (revert)---------
# ----------------------------------------------------------
echo '--- Disable Firefox new profile ping (revert)'
pref_name='toolkit.telemetry.newProfilePing.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -----------Disable Firefox update ping (revert)-----------
# ----------------------------------------------------------
echo '--- Disable Firefox update ping (revert)'
pref_name='toolkit.telemetry.updatePing.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ------------Disable Firefox prio ping (revert)------------
# ----------------------------------------------------------
echo '--- Disable Firefox prio ping (revert)'
pref_name='toolkit.telemetry.prioping.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----Disable Firefox Pioneer study monitoring (revert)-----
# ----------------------------------------------------------
echo '--- Disable Firefox Pioneer study monitoring (revert)'
pref_name='toolkit.telemetry.pioneer-new-studies-available'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Clear Firefox pioneer program ID (revert)---------
# ----------------------------------------------------------
echo '--- Clear Firefox pioneer program ID (revert)'
pref_name='toolkit.telemetry.pioneerId'
pref_value='""'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# ----Disable Firefox plugin stability blocking (revert)----
# ----------------------------------------------------------
echo '--- Disable Firefox plugin stability blocking (revert)'
pref_name='browser.safebrowsing.blockedURIs.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Disable Firefox application reputation checks for downloads (revert)
echo '--- Disable Firefox application reputation checks for downloads (revert)'
pref_name='browser.safebrowsing.downloads.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------Disable Firefox malware protection (revert)--------
# ----------------------------------------------------------
echo '--- Disable Firefox malware protection (revert)'
pref_name='browser.safebrowsing.malware.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------Disable Firefox phishing protection (revert)-------
# ----------------------------------------------------------
echo '--- Disable Firefox phishing protection (revert)'
pref_name='browser.safebrowsing.phishing.enabled'
pref_value='false'
echo "Reverting preference: \"$pref_name\" to its default."
declare -a profile_paths=(
  ~/.mozilla/firefox/*/
  ~/.var/app/org.mozilla.firefox/.mozilla/firefox/*/
  ~/snap/firefox/common/.mozilla/firefox/*/
)
declare -i total_profiles_found=0
for profile_dir in "${profile_paths[@]}"; do
  user_js_file="${profile_dir}user.js"
  if [ ! -f "$user_js_file" ]; then
    continue
  fi
  ((total_profiles_found++))
  echo "$user_js_file:"
  pref_start="user_pref(\"$pref_name\","
  pref_line="user_pref(\"$pref_name\", $pref_value);"
  if ! grep --quiet "^$pref_start" "${user_js_file}"; then
    echo $'\t''Skipping, preference was not configured before.'
  elif grep --quiet "^$pref_line$" "${user_js_file}"; then
    sed --in-place "/^$pref_line/d" "$user_js_file"
    echo $'\t''Successfully reverted preference to default.'
    if ! grep --quiet '[^[:space:]]' "$user_js_file"; then
      rm "$user_js_file"
      echo $'\t''Removed user.js file as it became empty.'
    fi
  else
    echo $'\t''Skipping, the preference has value that is not configured by privacy.sexy.'
  fi
done
if [ "$total_profiles_found" -eq 0 ]; then
  echo 'No reversion was necessary.'
else
  echo "Preferences verified in $total_profiles_found profiles."
fi
# ----------------------------------------------------------


# Disable Python history for future interactive commands (revert)
echo '--- Disable Python history for future interactive commands (revert)'
history_file="$HOME/.python_history"
if [ ! -f "$history_file" ]; then
  echo "Skipping, $history_file does not exist."
else
  sudo chattr -i "$(realpath $history_file)" # realpath in case of symlink
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# -------------Disable .NET telemetry (revert)--------------
# ----------------------------------------------------------
echo '--- Disable .NET telemetry (revert)'
variable='DOTNET_CLI_TELEMETRY_OPTOUT'
value='1'
declaration_file='/etc/environment'
if ! [ -f "$declaration_file" ]; then
  echo "Skipping, \"$declaration_file\" does not exist."
else
  assignment="$variable=$value"    
  if grep --quiet "^$assignment$" "${declaration_file}"; then
    if sudo sed --in-place "/^$assignment$/d" "$declaration_file"; then
      echo "Successfully deleted \"$variable\" with \"$value\"."
    else
      >&2 echo "Failed to delete \"$assignment\"."
    fi
  else
    echo "Skipping, \"$variable\" with \"$value\" is not found."
  fi
fi
# ----------------------------------------------------------


# ----------------------------------------------------------
# --------Disable PowerShell Core telemetry (revert)--------
# ----------------------------------------------------------
echo '--- Disable PowerShell Core telemetry (revert)'
variable='POWERSHELL_TELEMETRY_OPTOUT'
value='1'
declaration_file='/etc/environment'
if ! [ -f "$declaration_file" ]; then
  echo "Skipping, \"$declaration_file\" does not exist."
else
  assignment="$variable=$value"    
  if grep --quiet "^$assignment$" "${declaration_file}"; then
    if sudo sed --in-place "/^$assignment$/d" "$declaration_file"; then
      echo "Successfully deleted \"$variable\" with \"$value\"."
    else
      >&2 echo "Failed to delete \"$assignment\"."
    fi
  else
    echo "Skipping, \"$variable\" with \"$value\" is not found."
  fi
fi
# ----------------------------------------------------------


echo 'Your privacy and security is now hardened 🎉💪'
echo 'Press any key to exit.'
read -n 1 -s