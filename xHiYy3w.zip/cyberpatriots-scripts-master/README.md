## Windows script

Originally written by [Frostbyte](https://github.com/Catalyst4222/cyberpatriot-scripts)

You're gonna have to test in a Windows VM sorry.

## Docker testing the bash script

First, install [Docker](https://docs.docker.com/get-docker/), [Docker Compose](https://docs.docker.com/compose/install/) and probably [Docker Desktop](https://www.docker.com/products/docker-desktop/) too.

- Run `docker-compose build ubuntu-test`
- Run `docker-compose run ubuntu-test`

(You will have to rebuild every time you change the script)