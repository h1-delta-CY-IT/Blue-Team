# TODO: use a log file like in the bash script?
# TODO: services, internet properties, network shares, ?

if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
    Start-Process -FilePath PowerShell.exe -Verb Runas -ArgumentList "-File `"$($MyInvocation.MyCommand.Path)`"  `"$($MyInvocation.MyCommand.UnboundArguments)`""
    Exit
}

Write-Host "It's ya boy James here with the script credit to Frostbyte for making the Python version and for giving me pain cuz python is dumb"

$scriptDir = ".\windows-scripts"

function Write-Todo {
    Write-Host "TODO"
}

function Find-UserMediaFiles {
    $fileTypes = @(
        "*.midi", "*.mid", "*.mod", "*.mp3", "*.mp2", "*.mpa", "*.abs", "*.mpega",
        "*.au", "*.snd", "*.wav", "*.aiff", "*.aif", "*.sid", "*.flac", "*.ogg",

        "*.mpeg", "*.mpg", "*.mpe", "*.dl", "*.movie", "*.movi", "*.mv", "*.iff",
        "*.anim5", "*.anim3", "*.anim7", "*.avi", "*.vfw", "*.avx", "*.fli", "*.flc",
        "*.mov", "*.qt", "*.spl", "*.swf", "*.dcr", "*.dir", "*.dxr", "*.rpm",
        "*.rm", "*.smi", "*.ra", "*.ram", "*.rv", "*.wmv", "*.asf", "*.asx",
        "*.wma", "*.wax", "*.wmv", "*.wmx", "*.3gp", "*.mov", "*.mp4", "*.avi",
        "*.swf", "*.flv", "*.m4v",

        "*.tiff", "*.tif", "*.rs", "*.im1", "*.gif", "*.jpeg", "*.jpg", "*.jpe",
        "*.png", "*.rgb", "*.xwd", "*.xpm", "*.ppm", "*.pbm", "*.pgm", "*.pcx",
        "*.ico", "*.svg", "*.svgz"
    )

    $logFile = New-Item -Type File -Path "C:\findmedia-results.txt"
    $startDirectory = "C:\Users\"

    Write-Host "Press Q to abort."
    foreach ($type in $fileTypes) {
        if ([Console]::KeyAvailable) {
            $key = [System.Console]::ReadKey($true)
            if ($key.KeyChar -eq 'q' -or $key.KeyChar -eq 'Q') {
                Write-Host "Aborted by user."
                break
            }
        }

        Write-Host "Scanning for $type files..."
        Get-ChildItem -Path $startDirectory -Recurse -Filter $type -ErrorAction SilentlyContinue | 
        ForEach-Object {
            $_.FullName | Out-File -Append $logFile
        }
    }
    Write-Host "Written to C:\findmedia-results.txt"
}

function Initialize-Services {
    # thanks chatgpt

    Write-Host "The script will run you through several services, answer yes/y or no/n:"
    
    $services = @(
        @{ Name = "RemoteRegistry"; Display = "Remote Registry"; Recommended = $false },
        @{ Name = "TermService"; Display = "Remote Desktop"; Recommended = $false },
        @{ Name = "lmhosts"; Display = "TCP/IP NetBIOS Helper"; Recommended = $false },
        @{ Name = "Spooler"; Display = "Printing"; Recommended = $false },
        @{ Name = "Sense"; Display = "Windows Defender Advanced Threat Protection Service"; Recommended = $true },
        @{ Name = "mpssvc"; Display = "Windows Defender Firewall"; Recommended = $true },
        @{ Name = "EventLog"; Display = "Windows Event Log"; Recommended = $true },
        @{ Name = "wuauserv"; Display = "Windows Update"; Recommended = $true }
    )
    
    foreach ($service in $services) {
        Write-Host -NoNewline ("Does this machine need " + $service.Display + "? ")
        if ($service.Recommended) {
            Write-Host "(recommended)"
        }
        else {
            Write-Host "(not recommended)"
        }
        $userChoice = Read-Host
    
        if (-not $userChoice) {
            # Empty string
            continue
        }

        switch ($userChoice.ToLower().Substring(0, 1)) {
            "y" {
                Set-Service -Verbose -Name $service.Name -StartupType Automatic -Status Running
            }
            "n" {
                Set-Service -Verbose -Name $service.Name -StartupType Disabled -Status Stopped
            }
        }
    }
}

Write-Host @"

So the question is... what do you want to do? Enter the desired keyword:

checkusers: Check for unauthorized users and admins
findmedia: Identify all media files from all user directories 
passwordoverride: Override every password
lgpoimport: Import LGPO
lgpoexport: Export LGPO
services: Enable/disable optional services
uac2: Set UAC to level 2
secureremote: Secure and disable remote desktop/remote assistance
showtasks: Show every non-default task (may be defective)
exit: Exit the script
"@
$choice = Read-Host

switch ($choice) {
    "exit" {
        return 0
    }
    "checkusers" {
        Write-Todo
    }
    "findmedia" {
        Find-UserMediaFiles
    }
    "passwordoverride" {
        $password = Read-Host "Choose the password to set for *every* user"
        & "$scriptDir\Set-GlobalPassword.ps1" $password
    }
    "services" {
        Initialize-Services
    }
    "uac2" {
        Import-Module $scriptDir\reg.ps1
        Set-UACLevel
    }
    "secureremote" {
        & "$scriptDir\rmtdsktp.ps1"
    }
    "showtasks" {
        Write-Host "Loading tasks..."
        & "$scriptDir\tasks.ps1"
    }
    "lgpoimport" {
        Write-Todo
    }
    "lgpoexport" {
        & "$scriptDir\LGPO.exe /b $scriptDir"
    }
}